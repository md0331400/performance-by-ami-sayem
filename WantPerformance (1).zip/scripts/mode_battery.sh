#!/system/bin/sh
##############################################
# BATTERY SAVE MODE - Redmi 14C
# Screen off / locked
##############################################

CONFIG_DIR=/data/adb/want_performance
WHITELIST=$CONFIG_DIR/battery_whitelist.txt

echo ">>> BATTERY SAVE MODE"

# Force 60Hz to save power
settings put system peak_refresh_rate 60.0
settings put system min_refresh_rate 60.0
settings put system user_refresh_rate 60
settings put secure miui_refresh_rate 60
settings put global miui_refresh_rate 60

# MediaTek battery mode
echo 2 > /proc/cpufreq/cpufreq_power_mode 2>/dev/null

# CPU powersave
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    if [ -f "$cpu" ]; then
        echo "powersave" > "$cpu" 2>/dev/null || echo "conservative" > "$cpu" 2>/dev/null
    fi
done

# Disable big cores (A75) to save battery
echo 0 > /sys/devices/system/cpu/cpu6/online 2>/dev/null
echo 0 > /sys/devices/system/cpu/cpu7/online 2>/dev/null

# GPU powersave
for mali in /sys/devices/platform/*.mali /sys/devices/platform/mali*; do
    if [ -d "$mali" ]; then
        echo "coarse_demand" > $mali/power_policy 2>/dev/null
        echo "powersave" > $mali/devfreq/governor 2>/dev/null
    fi
done

# Kill all non-whitelisted apps
ALL_APPS=$(pm list packages -3 2>/dev/null | sed 's/package://g')
for pkg in $ALL_APPS; do
    if grep -qx "$pkg" "$WHITELIST" 2>/dev/null; then
        continue
    fi
    case "$pkg" in
        com.android.*|*.systemui|*.phone|*.bluetooth|*.dialer|*.contacts|com.google.android.gms|com.google.android.gsf|com.mediatek.*|com.miui.core|me.weishu.*)
            continue ;;
    esac
    am force-stop "$pkg" 2>/dev/null
done

# Aggressive doze
dumpsys deviceidle enable all 2>/dev/null
dumpsys deviceidle force-idle 2>/dev/null

# Clear RAM
echo 3 > /proc/sys/vm/drop_caches
sync

# Enable battery saver
settings put global low_power 1
cmd power set-mode 1

echo ">>> Battery save mode applied"

# Notification
sh /data/adb/modules/want_performance/scripts/notify.sh battery &
