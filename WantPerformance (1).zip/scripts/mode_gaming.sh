#!/system/bin/sh
##############################################
# GAMING MODE - Optimized for Redmi 14C
# Chipset: MediaTek Helio G81 Ultra
# GPU: Mali-G52 MC2
# Display: 120Hz HD+ IPS LCD
# OS: HyperOS (Android 14)
##############################################

GAME_PKG="$1"
CONFIG_DIR=/data/adb/want_performance
MAX_BG=$(cat $CONFIG_DIR/max_bg_apps 2>/dev/null || echo 2)

echo ">>> GAMING MODE for: $GAME_PKG"

#######################################
# 1. FORCE 120Hz (HyperOS specific)
#######################################
# Standard AOSP
settings put system peak_refresh_rate 120.0
settings put system min_refresh_rate 120.0
settings put secure peak_refresh_rate 120.0
settings put secure min_refresh_rate 120.0

# HyperOS / MIUI specific keys
settings put system user_refresh_rate 120
settings put secure miui_refresh_rate 120
settings put global miui_refresh_rate 120
settings put system screen_refresh_rate 120
settings put system default_refresh_rate 120

# DISABLE HyperOS's smart DFPS (this caps to 60!)
settings put secure smart_dfps 0
settings put system smart_dfps 0
settings put global miui_dynamic_fps 0
settings put secure adaptive_refresh_rate_disabled 1

# Disable HyperOS Game Booster auto-management
settings put secure game_booster_enable 0
settings put secure miui_game_booster_enable 0

# Force display mode via SurfaceFlinger
service call SurfaceFlinger 1035 i32 0 >/dev/null 2>&1

# Disable battery saver (it caps refresh rate)
settings put global low_power 0
cmd power set-mode 0

echo "  120Hz forced via all methods"

#######################################
# 2. MEDIATEK CPU PERFORMANCE
# Helio G81: 2x A75 (big) + 6x A55 (little)
#######################################
# MediaTek power mode (1 = performance, 0 = balance, 2 = battery)
echo 1 > /proc/cpufreq/cpufreq_power_mode 2>/dev/null

# Standard governor approach (fallback)
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$cpu" ] && echo "performance" > "$cpu" 2>/dev/null
done

# Lock to max frequency
for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
    if [ -d "$cpu" ]; then
        MAX=$(cat $cpu/cpuinfo_max_freq 2>/dev/null)
        [ -n "$MAX" ] && echo "$MAX" > $cpu/scaling_min_freq 2>/dev/null
    fi
done

# Boost big cores (A75) specifically
for cpu in 6 7; do
    echo 1 > /sys/devices/system/cpu/cpu$cpu/online 2>/dev/null
done

# MediaTek interactive tweaks
echo "0 1800000:99" > /proc/perfmgr/syslimiter/syslimiter_freq_limit 2>/dev/null
echo "1" > /proc/perfmgr/boost_ctrl/cpu_ctrl/policy_boot_boost 2>/dev/null
echo "1" > /sys/module/mtk_fpsgo/parameters/perfmgr_enable 2>/dev/null

# Disable thermal limiting briefly (use with caution!)
echo "0" > /sys/class/thermal/thermal_message/sconfig 2>/dev/null
echo "disabled" > /sys/class/thermal/thermal_zone0/mode 2>/dev/null

echo "  MediaTek CPU set to performance"

#######################################
# 3. MALI-G52 GPU MAX PERFORMANCE
# MediaTek Mali GPU paths
#######################################
# MediaTek GPUFreq v1
echo "performance" > /proc/gpufreq/gpufreq_opp_freq 2>/dev/null
echo 0 > /proc/gpufreq/gpufreq_opp_freq 2>/dev/null  # 0 = highest OPP

# MediaTek GPUFreq v2 (newer kernels)
MAX_GPU=$(cat /proc/gpufreqv2/gpu_working_opp_table 2>/dev/null | head -1 | awk '{print $4}')
[ -n "$MAX_GPU" ] && echo $MAX_GPU > /proc/gpufreqv2/fix_target_opp_index 2>/dev/null

# Mali specific
for mali in /sys/devices/platform/*.mali /sys/devices/platform/mali*; do
    if [ -d "$mali" ]; then
        echo "always_on" > $mali/power_policy 2>/dev/null
        echo "performance" > $mali/devfreq/governor 2>/dev/null
        MAX=$(cat $mali/devfreq/available_frequencies 2>/dev/null | tr ' ' '\n' | sort -nr | head -1)
        [ -n "$MAX" ] && echo "$MAX" > $mali/devfreq/min_freq 2>/dev/null
    fi
done

# Disable GPU idle
echo 0 > /proc/mali/dvfs_enable 2>/dev/null
echo 1 > /sys/module/ged/parameters/gpu_dvfs_enable 2>/dev/null  # 1=force max in some kernels

echo "  Mali-G52 set to max performance"

#######################################
# 4. KILL BACKGROUND APPS
#######################################
RUNNING=$(dumpsys activity processes 2>/dev/null | grep -oE 'ProcessRecord\{[^}]+\}' | grep -oE '[a-zA-Z0-9._]+/[0-9]+' | cut -d'/' -f1 | sort -u)

KEEP=0
for pkg in $RUNNING; do
    case "$pkg" in
        android|com.android.*|com.google.android.gms|com.google.android.gsf|com.google.android.gms.*|*.systemui|*.phone|*.bluetooth|*.nfc|com.mediatek.*|com.miui.core|com.miui.system|com.miui.securitycore|com.xiaomi.misettings|com.xiaomi.market|me.weishu.*|com.dergoogler.*)
            continue ;;
    esac
    [ "$pkg" = "$GAME_PKG" ] && continue
    if [ $KEEP -lt $MAX_BG ]; then
        KEEP=$((KEEP + 1))
        continue
    fi
    am force-stop "$pkg" 2>/dev/null
done

#######################################
# 5. RAM CLEAR (important for 4GB variant!)
#######################################
echo 3 > /proc/sys/vm/drop_caches
sync
# More aggressive for low RAM device
echo 100 > /proc/sys/vm/vfs_cache_pressure 2>/dev/null
echo 10 > /proc/sys/vm/swappiness 2>/dev/null

#######################################
# 6. NETWORK / IO
#######################################
echo 1 > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null

# I/O scheduler for eMMC (Redmi 14C uses eMMC 5.1)
for block in /sys/block/mmcblk*/queue/scheduler; do
    [ -f "$block" ] && echo "noop" > "$block" 2>/dev/null || echo "none" > "$block" 2>/dev/null
done

echo ">>> Gaming mode applied: 120Hz + CPU/GPU max"

# Notification (after everything else)
sh /data/adb/modules/want_performance/scripts/notify.sh gaming "$GAME_PKG" &
