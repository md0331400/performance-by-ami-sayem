#!/system/bin/sh
##############################################
# Notification - HyperOS / Redmi 14C optimized
##############################################

MODE="$1"
EXTRA="$2"
LOG=/data/adb/want_performance/notify.log

case "$MODE" in
    gaming)
        TITLE="Gaming Mode ON  120Hz"
        MSG="Max FPS active. Background apps killed."
        [ -n "$EXTRA" ] && MSG="Playing: $EXTRA at 120Hz"
        ;;
    balance)
        TITLE="Balance Mode"
        MSG="Default phone behavior"
        ;;
    battery)
        TITLE="Battery Save Mode"
        MSG="Background apps restricted - 60Hz"
        ;;
    *)
        TITLE="Want Performance"
        MSG="$EXTRA"
        ;;
esac

echo "[$(date)] $TITLE - $MSG" >> $LOG

# HyperOS blocks notifications from UID 0 (root)
# Must run as shell user (UID 2000)

# Method 1: Standard shell user (works on HyperOS)
R1=$(su -lp 2000 -c "cmd notification post -S bigtext -t '$TITLE' WantPerf '$MSG'" 2>&1)
echo "M1: $R1" >> $LOG

# Method 2: If KernelSU available, try with explicit context
if [ -z "$R1" ] || echo "$R1" | grep -qi "fail\|error"; then
    R2=$(su -c "su shell -c \"cmd notification post -S bigtext -t '$TITLE' WantPerf '$MSG'\"" 2>&1)
    echo "M2: $R2" >> $LOG
fi

# Method 3: HyperOS toast via MIUI service
am start -a android.intent.action.MAIN -n "com.miui.securitycenter/.notificationcenter.NotificationManagerActivity" 2>/dev/null >/dev/null

# Keep log small
[ "$(wc -l < $LOG 2>/dev/null)" -gt 100 ] && tail -50 $LOG > ${LOG}.t && mv ${LOG}.t $LOG

exit 0
