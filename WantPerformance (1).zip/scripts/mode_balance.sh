#!/system/bin/sh
##############################################
# BALANCE MODE - Redmi 14C
# Restore HyperOS default behavior
##############################################

echo ">>> BALANCE MODE"

# Restore adaptive refresh rate (HyperOS default)
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
settings delete secure peak_refresh_rate
settings delete secure min_refresh_rate
settings put secure smart_dfps 1
settings put system smart_dfps 1
settings put global miui_dynamic_fps 1
settings put secure adaptive_refresh_rate_disabled 0
settings put secure game_booster_enable 1
settings put secure miui_game_booster_enable 1

# MediaTek balance mode
echo 0 > /proc/cpufreq/cpufreq_power_mode 2>/dev/null

# Reset CPU governor (schedutil is HyperOS default)
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    if [ -f "$cpu" ]; then
        echo "schedutil" > "$cpu" 2>/dev/null || echo "interactive" > "$cpu" 2>/dev/null
    fi
done

# Reset CPU min freq
for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
    if [ -d "$cpu" ]; then
        MIN=$(cat $cpu/cpuinfo_min_freq 2>/dev/null)
        [ -n "$MIN" ] && echo "$MIN" > $cpu/scaling_min_freq 2>/dev/null
    fi
done

# Reset Mali GPU to default
echo -1 > /proc/gpufreq/gpufreq_opp_freq 2>/dev/null
echo -1 > /proc/gpufreqv2/fix_target_opp_index 2>/dev/null
for mali in /sys/devices/platform/*.mali /sys/devices/platform/mali*; do
    if [ -d "$mali" ]; then
        echo "coarse_demand" > $mali/power_policy 2>/dev/null
        echo "simple_ondemand" > $mali/devfreq/governor 2>/dev/null
    fi
done
echo 1 > /proc/mali/dvfs_enable 2>/dev/null

# Re-enable thermal
echo "1" > /sys/class/thermal/thermal_message/sconfig 2>/dev/null
echo "enabled" > /sys/class/thermal/thermal_zone0/mode 2>/dev/null

# Reset I/O scheduler
for block in /sys/block/mmcblk*/queue/scheduler; do
    [ -f "$block" ] && echo "cfq" > "$block" 2>/dev/null || echo "bfq" > "$block" 2>/dev/null
done

echo ">>> Balance mode applied"

# Notification
sh /data/adb/modules/want_performance/scripts/notify.sh balance &
