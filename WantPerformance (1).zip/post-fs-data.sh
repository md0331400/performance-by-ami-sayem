#!/system/bin/sh
# Want Performance - post-fs-data
# Runs early on boot

MODDIR=${0%/*}
LOG=/data/adb/want_performance/boot.log

mkdir -p /data/adb/want_performance
echo "[$(date)] post-fs-data started" > $LOG

# Ensure config files exist
[ ! -f /data/adb/want_performance/current_mode ] && echo "balance" > /data/adb/want_performance/current_mode
[ ! -f /data/adb/want_performance/enabled ] && echo "1" > /data/adb/want_performance/enabled

chmod 755 $MODDIR/scripts/*.sh 2>/dev/null

echo "[$(date)] post-fs-data finished" >> $LOG
