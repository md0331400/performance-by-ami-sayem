#!/sbin/sh
##########################################################################
# Want Performance - Magisk Module
# Created by: Ami Sayem
##########################################################################

SKIPUNZIP=0

ui_print " "
ui_print "************************************"
ui_print "   WANT PERFORMANCE  v1.0.0"
ui_print "   Created by: Ami Sayem"
ui_print "************************************"
ui_print " "
ui_print "- Installing modules files..."

# Extract files
unzip -o "$ZIPFILE" 'scripts/*' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'webroot/*' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'system/*' -d "$MODPATH" >&2 2>/dev/null

ui_print "- Setting permissions..."
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/scripts" 0 0 0755 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755

# Create config directory
mkdir -p /data/adb/want_performance
echo "balance" > /data/adb/want_performance/current_mode
echo "1" > /data/adb/want_performance/enabled
echo "2" > /data/adb/want_performance/max_bg_apps

# Default whitelist for battery save mode (social apps)
cat > /data/adb/want_performance/battery_whitelist.txt <<EOF
com.facebook.katana
com.facebook.orca
com.whatsapp
com.instagram.android
com.zhiliaoapp.musically
com.ss.android.ugc.trill
org.telegram.messenger
com.discord
com.snapchat.android
com.twitter.android
com.google.android.gm
com.google.android.apps.messaging
com.android.systemui
com.android.phone
com.android.bluetooth
EOF

# Custom game package list (user can edit)
cat > /data/adb/want_performance/games.txt <<EOF
com.dts.freefireth
com.dts.freefiremax
com.tencent.ig
com.pubg.imobile
com.pubg.krmobile
com.activision.callofduty.shooter
com.mobile.legends
com.miHoYo.GenshinImpact
com.miHoYo.bh3.global
com.epicgames.fortnite
com.supercell.clashofclans
com.supercell.clashroyale
com.king.candycrushsaga
com.ea.gp.fifamobile
com.gameloft.android.ANMP.GloftA9HM
com.netease.lztgglobal
com.roblox.client
com.mojang.minecraftpe
com.garena.game.kgth
com.garena.game.codm
EOF

chmod 755 /data/adb/want_performance
chmod 644 /data/adb/want_performance/*

ui_print "- Configuration created at:"
ui_print "  /data/adb/want_performance/"
ui_print " "
ui_print "- Modes:"
ui_print "  [GAMING]  Auto-on when game opens"
ui_print "  [BALANCE] Default state"
ui_print "  [BATTERY] When screen off / locked"
ui_print " "
ui_print "- Edit games.txt to add more games"
ui_print "- Edit battery_whitelist.txt for whitelist"
ui_print " "
ui_print "- Reboot to activate!"
ui_print " "
