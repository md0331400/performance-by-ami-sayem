# ⚡ Want Performance — Magisk Module

**Created by: Ami Sayem**
Version: 1.0.0

Smart gaming/battery optimizer that auto-switches phone modes based on what you're doing.

---

## 🎯 Features

### 🎮 Gaming Mode (auto-activates when you open a game)
- Sets display to **maximum supported refresh rate** (60/90/120/144Hz)
- CPU governor → `performance` (max clocks)
- GPU → max performance, idle disabled
- Kills all background apps **except the game + 2 user apps**
- Clears RAM cache
- Enables FPS overlay (system-level; for in-game FPS, use an app like *Scene 5* or *GameBench*)

### ⚖️ Balance Mode (default state)
- All settings reset to phone defaults
- Schedutil/interactive CPU governor
- Normal refresh rate behavior

### 🔋 Battery Save Mode (auto when screen off / locked)
- Refresh rate → 60Hz
- CPU → `powersave` governor
- Kills all apps **except whitelisted** (FB, Messenger, WhatsApp, Instagram, TikTok, Telegram, Discord, Snapchat, Twitter, Gmail, SMS — editable)
- Forces Doze mode
- Enables Android battery saver

---

## 📲 Installation
1. Flash `WantPerformance.zip` in Magisk Manager / KernelSU / APatch
2. **Reboot**
3. The daemon starts automatically after boot

---

## 🖥️ App-like UI (Optional but Recommended)
Install **MMRL** ([Magisk Module Repo Loader](https://github.com/MMRLApp/MMRL)) from Play Store / GitHub. It will detect this module and show the beautiful WebUI bundled inside (`webroot/index.html`). You'll get:
- Live mode display
- Quick switch buttons
- Toggle module on/off
- Stats & config

---

## ⚙️ Configuration Files
Located at `/data/adb/want_performance/`:

| File | Purpose |
|---|---|
| `games.txt` | Game package names (one per line) |
| `battery_whitelist.txt` | Apps allowed to run in battery mode |
| `max_bg_apps` | How many bg apps to keep in game mode (default 2) |
| `enabled` | `1` = active, `0` = disabled |
| `current_mode` | Currently active mode |

**Add more games:** edit `games.txt` and add the package name (e.g., `com.example.game`).

---

## ⚠️ Limitations (Be Realistic)
- **In-game FPS overlay**: Magisk can't draw on top of games. Use Scene 5 / GameBench / your ROM's built-in Game Mode for that.
- **Per-game graphics control**: Most games don't allow external graphic changes. Use *GFX Tool* type apps for that. This module does system-wide GPU boost only.
- **Compatibility**: CPU/GPU sysfs paths vary by chipset (tested for Snapdragon Adreno & Mediatek Mali). If something doesn't work, check `/data/adb/want_performance/daemon.log`.

---

## 🐛 Debugging
Logs are saved at:
- `/data/adb/want_performance/daemon.log` — main detection
- `/data/adb/want_performance/service.log` — boot service
- `/data/adb/want_performance/boot.log` — early boot

Tail with: `tail -f /data/adb/want_performance/daemon.log`

---

Made with ♥ by **Ami Sayem**
