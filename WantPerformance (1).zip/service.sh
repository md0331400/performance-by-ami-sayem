#!/system/bin/sh
# Want Performance - main service
# Runs in late_start service mode (after boot)
# Created by: Ami Sayem

MODDIR=${0%/*}
CONFIG_DIR=/data/adb/want_performance
LOG=$CONFIG_DIR/service.log

# Wait for boot to finish
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
done
sleep 30  # extra wait for system stability

echo "[$(date)] Want Performance service started" > $LOG

# Welcome notification
sh $MODDIR/scripts/notify.sh balance &
sleep 2
cmd notification post -S bigtext -t "⚡ Want Performance Active" "want_perf_boot" "Module loaded by Ami Sayem. Auto-detecting mode..." 2>/dev/null

# Start the main daemon in background
nohup sh $MODDIR/scripts/daemon.sh >> $LOG 2>&1 &
echo $! > $CONFIG_DIR/daemon.pid

echo "[$(date)] Daemon PID: $(cat $CONFIG_DIR/daemon.pid)" >> $LOG
